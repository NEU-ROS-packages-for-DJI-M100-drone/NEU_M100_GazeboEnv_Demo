^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rotors_joy_interface
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

6.0.2 (2019-12-28)
------------------
* Add joystick interface for the Crazyflie
* Contributors: Giuseppe Silano

6.0.1 (2019-12-28)
------------------

4.0.6 (2019-01-04)
------------------

4.0.5 (2018-12-17)
------------------

4.0.4 (2018-09-30)
------------------

4.0.3 (2018-06-04)
------------------

4.0.2 (2018-02-23)
------------------

4.0.1 (2018-02-02)
------------------
* initial Ubuntu package release
* Contributors: Giuseppe Silano, Emanuele Aucone, Benjamin Rodriguez, Luigi Iannelli
