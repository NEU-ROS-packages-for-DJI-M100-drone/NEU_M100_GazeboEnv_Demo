^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rotors_gazebo_plugins
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

6.0.2 (2020-02-09)
------------------

6.0.1 (2019-12-28)
------------------
* The package has been made compatible with ROS Melodic and Gazebo 9. The RotorS's feature/gazebo9 branch has been used as a basis.
* Contributors: Giuseppe Silano

4.0.6 (2019-01-04)
------------------

4.0.5 (2018-12-17)
------------------
* The crazyflie2_hovering_example.launch file has been modified considering the changes made on the position_controller_node
* Contributors: Giuseppe Silano

4.0.4 (2018-09-30)
------------------

4.0.3 (2018-06-04)
------------------
* Inserted the measuerement divisor into the gazebo plugin aimed to model the Inertial Measurement Unit (IMU)
* Contributors: Giuseppe Silano

4.0.2 (2018-02-23)
------------------

4.0.1 (2018-02-02)
------------------
* initial package Ubuntu release
* Contributors: Giuseppe Silano, Emanuele Aucone, Benjamin Rodriguez, Luigi Iannelli
